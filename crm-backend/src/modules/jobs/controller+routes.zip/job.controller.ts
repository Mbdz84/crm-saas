import { Request, Response } from "express";
import prisma from "../../prisma/client";
import twilio from "twilio";
import { Decimal } from "@prisma/client/runtime/library";
import OpenAI from "openai";

import { defaultSmsSettings } from "../smsSettings/smsSettings.controller";

declare global {
  namespace Express {
    interface Request {
      user?: any;
    }
  }
}

// --- SMS FIELD KEYS (shared with smsSettings but duplicated locally) ---
type SmsFieldKey =
  | "id"
  | "name"
  | "phone"
  | "address"
  | "jobType"
  | "notes"
  | "appointment"
  | "leadSource";

interface SmsSettings {
  order: SmsFieldKey[];
  show: Record<SmsFieldKey, boolean>;
  showLabel: Record<SmsFieldKey, boolean>;
  label: Record<SmsFieldKey, string>;
}

// OPENAI
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

const PARSE_MODEL = process.env.OPENAI_PARSE_MODEL || "gpt-4.1";

/* ============================================================
   TWILIO CLIENT
============================================================ */

const twilioClient = twilio(
  process.env.TWILIO_ACCOUNT_SID!,
  process.env.TWILIO_AUTH_TOKEN!
);

const TWILIO_NUMBER = process.env.TWILIO_NUMBER;


/* ============================================================
   TWILIO ext refresh
============================================================ */
export async function refreshExtension(req: Request, res: Response) {
  console.log("🔵 refreshExtension() HIT");
  console.log("🔵 params.shortId =", req.params.shortId);
  console.log("🔵 req.user =", req.user);

  try {
    const shortId = req.params.shortId.toUpperCase();

    const job = await prisma.job.findFirst({
      where: { shortId, companyId: req.user!.companyId }
    });

    console.log("🔵 Job lookup:", job);

    if (!job) {
      console.log("❌ Job not found for shortId:", shortId);
      return res.status(404).json({ error: "Job not found" });
    }

    if (!job.technicianId) {
      console.log("❌ No technician assigned");
      return res.status(400).json({ error: "No technician assigned" });
    }

    const newExt = Math.floor(100 + Math.random() * 9000).toString();
    console.log("🔵 New EXT =", newExt);

    const existing = await prisma.jobCallSession.findFirst({
      where: {
        jobId: job.id,
        technicianId: job.technicianId
      }
    });

    console.log("🔵 Existing session =", existing);

    let updated;

    if (existing) {
      updated = await prisma.jobCallSession.update({
        where: { id: existing.id },
        data: { extension: newExt }
      });
      console.log("🟢 Updated existing EXT:", updated);
    } else {
      updated = await prisma.jobCallSession.create({
        data: {
          jobId: job.id,
          technicianId: job.technicianId,
          customerPhone: job.customerPhone || "",
          extension: newExt,
          companyId: job.companyId
        }
      });
      console.log("🟢 Created new EXT session:", updated);
    }

    return res.json({
      message: "Extension refreshed",
      extension: newExt,
      sessionId: updated.id
    });

  } catch (err) {
    console.error("🔥 REFRESH EXT ERROR:", err);
    return res.status(500).json({ error: "Failed to refresh extension" });
  }
}

/* ============================================================
   SHORT-ID GENERATOR (5-character)
============================================================ */
async function generateUniqueShortId(): Promise<string> {
  while (true) {
    const shortId = Math.random().toString(36).substring(2, 7).toUpperCase();
    const exists = await prisma.job.findUnique({ where: { shortId } });
    if (!exists) return shortId;
  }
}
/* ============================================================
   PARSE JOB FROM RAW TEXT (AI)
============================================================ */

export async function parseJobFromText(req: Request, res: Response) {
  try {
    const { text } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ error: "Missing text" });
    }

    const prompt = `
Extract the following fields from the text. Return ONLY valid JSON:

{
  "source": "",
  "customerName": "",
  "customerPhone": "",
  "customerAddress": "",
  "jobType": "",
  "description": ""
}

Text:
${text}
`;

    const completion = await openai.chat.completions.create({
      model: PARSE_MODEL || "gpt-4.1",
      messages: [{ role: "user", content: prompt }],
      temperature: 0,
    });

    const raw = completion.choices?.[0]?.message?.content || "";
    console.log("AI RAW OUTPUT:", raw);

    if (!raw.trim()) {
      return res.status(500).json({ error: "AI returned empty output" });
    }

    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (err) {
      console.error("❌ Failed to parse JSON:", raw);
      return res.status(500).json({ error: "AI parse error" });
    }

    // -----------------------------------------------------
    // CLEAN ADDRESS — KEEP ONLY 5-DIGIT ZIP
    // -----------------------------------------------------
    function normalizeAddress(address: string): string {
      if (!address) return "";

      let a = address;

      // Remove country
      a = a.replace(/,?\s*United States/i, "");

      // Trim ZIP+4 → ZIP
      a = a.replace(/(\d{5})-\d{4}/, "$1");

      // Remove junk AFTER ZIP
      a = a.replace(/(\d{5}).*$/, "$1");

      // Clean double commas & spaces
      a = a.replace(/\s+/g, " ").replace(/,\s*,/g, ", ").trim();

      return a;
    }

    const cleanedAddress = parsed.customerAddress
      ? normalizeAddress(parsed.customerAddress)
      : null;

    // -----------------------------------------------------
    // Build clean result
    // -----------------------------------------------------
    const result = {
      source: parsed.source || null,
      customerName: parsed.customerName || null,
      customerPhone: parsed.customerPhone || null,
      customerAddress: cleanedAddress || null,
      jobType: parsed.jobType || null,
      description: parsed.description || null,
    };

    return res.json(result);
  } catch (err) {
    console.error("🔥 PARSE ERROR:", err);
    return res.status(500).json({ error: "Failed to parse job text" });
  }
}

/* ============================================================
   PHONE NORMALIZER (for masking sessions)
============================================================ */
function normalizePhone(raw: string | null | undefined): string | null {
  if (!raw) return null;
  // VERY simple cleaner – you can upgrade later to use libphonenumber
  const digits = raw.replace(/[^\d+]/g, "");
  if (!digits) return null;

  // if it already starts with +, assume E.164
  if (digits.startsWith("+")) return digits;

  // naive US logic: prepend +1 if 10 digits
  if (/^\d{10}$/.test(digits)) return "+1" + digits;

  return digits;
}
/* ============================================================
   CREATE JOB FROM PARSED FIELDS Ai
============================================================ */

export async function createJobFromParsed(req: Request, res: Response) {
  try {
    const {
      customerName,
      customerPhone,
      customerAddress,
      jobType,
      description,
      source,
    } = req.body;

    const user = req.user;
    if (!user?.companyId) {
      return res.status(401).json({ error: "Unauthorized" });
    }

    const companyId = user.companyId;

    // Generate unique short ID
    const shortId = await generateUniqueShortId();

    // Look up job type by name
    let jobTypeId: string | null = null;
    if (jobType) {
      const jt = await prisma.jobType.findFirst({
        where: {
          name: jobType.trim(),
          companyId,
        },
      });
      jobTypeId = jt?.id || null;
    }

    // Look up or create LeadSource
    let sourceId: string | null = null;
    if (source) {
      const ls = await prisma.leadSource.findFirst({
        where: {
          name: source.trim(),
          companyId,
        },
      });

      if (ls) {
        sourceId = ls.id;
      } else {
        const created = await prisma.leadSource.create({
          data: {
            name: source.trim(),
            companyId,
          },
        });
        sourceId = created.id;
      }
    }

    const title =
      customerName && jobType
        ? `${customerName} - ${jobType}`
        : customerName || jobType || "New Job";

    const job = await prisma.job.create({
      data: {
        shortId,
        title,
        customerName: customerName || null,
        customerPhone: customerPhone || null,
        customerAddress: customerAddress || null,
        description: description || null,
        jobTypeId,
        sourceId,
        technicianId: null,
        scheduledAt: null,
        status: "Accepted",
        companyId,
      },
      include: {
        technician: true,
        jobType: true,
        source: true,
        jobStatus: true,
      },
    });

    // 🆕 Save the raw SMS text as a job log
    if (req.body.__rawText) {
      await prisma.jobLog.create({
        data: {
          jobId: job.id,
          type: "parsed_sms",
          text: req.body.__rawText,
          userId: req.user.id,
        },
      });
    }

    return res.json({ message: "Job created", job, shortId });
  } catch (err) {
    console.error("🔥 CREATE JOB FROM PARSED ERROR:", err);
    return res.status(500).json({ error: "Failed to create parsed job" });
  }
}

/* ============================================================
   closing job
============================================================ */

export async function closeJob(req: Request, res: Response) {
  try {
    const { shortId } = req.params;

    const job = await prisma.job.findUnique({
      where: { shortId },
      include: {
        company: true,
      },
    });

    if (!job) {
      return res.status(404).json({ error: "Job not found" });
    }

    // basic multi-tenant check (same style as other controllers)
    const user = req.user;
    if (!user || user.companyId !== job.companyId) {
      return res.status(403).json({ error: "Forbidden" });
    }

    // Expecting body from frontend formula engine
    const body = req.body || {};

    const {
      invoiceNumber,

      payments,

      totalAmount,
      totalCcFee,
      techParts,
      leadParts,
      companyParts,
      totalParts,
      adjustedTotal,

      techPercent,
      leadPercent,
      companyPercent,

      excludeTechFromParts,
      techPaysAdditionalFee,
      leadAdditionalFee,
      leadOwnedByCompany,

      techProfit,
      leadProfit,
      companyProfitBase,
      companyProfitDisplay,

      techBalance,
      leadBalance,
      companyBalance,

      sumCheck,
    } = body;

// -----------------------------------------------------
// PAYMENT TOTALS (cash / credit / check / zelle)
// -----------------------------------------------------
let cashTotal = 0;
let creditTotal = 0;
let checkTotal = 0;
let zelleTotal = 0;

if (Array.isArray(payments)) {
  payments.forEach((p: any) => {
    const amt = Number(p.amount) || 0;
    switch (p.payment) {
      case "cash":   cashTotal += amt; break;
      case "credit": creditTotal += amt; break;
      case "check":  checkTotal += amt; break;
      case "zelle":  zelleTotal += amt; break;
    }
  });
}


///end


    // Derive a simple average CC% on ONLY non-cash payments for reporting
    let ccFeePercentAvg: number | null = null;
    if (Array.isArray(payments) && totalCcFee > 0) {
      const ccBase = payments
        .filter((p: any) => p.payment === "credit")
        .reduce(
          (s: number, p: any) => s + (Number(p.amount) || 0),
          0
        );

      if (ccBase > 0) {
        ccFeePercentAvg = (Number(totalCcFee) / ccBase) * 100;
      }
    }

    // ----------------------------------------------
    // Fetch the "Closed" status row
    // ----------------------------------------------
    const closedStatus = await prisma.jobStatus.findFirst({
      where: { name: "Closed", active: true },
    });

    if (!closedStatus) {
      return res.status(400).json({ error: "Closed status not found" });
    }

    // Use transaction to update Job + upsert JobClosing together
    const result = await prisma.$transaction(async (tx) => {
      // Status selected on the frontend (Pending Close OR Closed)
      const newStatusId = req.body.statusId ?? job.statusId;

      // Decide whether this is FINAL close
      const isFinalClose = newStatusId === closedStatus.id;

      // Update Job
      const updatedJob = await tx.job.update({
        where: { id: job.id },
        data: {
          // Lock ONLY for final close
          isClosingLocked: isFinalClose,
          // closedAt only when fully Closed
          closedAt: isFinalClose ? new Date() : null,
          // Can be Pending Close or Closed, depending on dropdown
          statusId: newStatusId,
        },
      });

      // Upsert JobClosing record
      const closing = await tx.jobClosing.upsert({
        where: { jobId: job.id },
        update: {
          invoiceNumber: invoiceNumber || null,
          payments: Array.isArray(payments) ? payments : [],

          totalAmount: Number(totalAmount) || 0,
          totalCcFee: Number(totalCcFee) || 0,
          ccFeePercentAvg,

          techParts: Number(techParts) || 0,
          leadParts: Number(leadParts) || 0,
          companyParts: Number(companyParts) || 0,
          totalParts: Number(totalParts) || 0,
          adjustedTotal: Number(adjustedTotal) || 0,

          techPercent: Number(techPercent) || 0,
          leadPercent: Number(leadPercent) || 0,
          companyPercent: Number(companyPercent) || 0,

          excludeTechFromParts: !!excludeTechFromParts,
          techPaysAdditionalFee: !!techPaysAdditionalFee,
          leadAdditionalFee: Number(leadAdditionalFee) || 0,
          leadOwnedByCompany: !!leadOwnedByCompany,

          techProfit: Number(techProfit) || 0,
          leadProfit: Number(leadProfit) || 0,
          companyProfitBase: Number(companyProfitBase) || 0,
          companyProfitDisplay: Number(companyProfitDisplay) || 0,

          techBalance: Number(techBalance) || 0,
          leadBalance: Number(leadBalance) || 0,
          companyBalance: Number(companyBalance) || 0,

          sumCheck: Number(sumCheck) || 0,

          // 🔥 NEW PAYMENT TOTALS
         cashTotal,
         creditTotal,
         checkTotal,
         zelleTotal,

          closedAt: isFinalClose ? new Date() : undefined,
          closedByUserId: user.id,
        },
        create: {
          jobId: job.id,
          invoiceNumber: invoiceNumber || null,
          payments: Array.isArray(payments) ? payments : [],

          totalAmount: Number(totalAmount) || 0,
          totalCcFee: Number(totalCcFee) || 0,
          ccFeePercentAvg,

          techParts: Number(techParts) || 0,
          leadParts: Number(leadParts) || 0,
          companyParts: Number(companyParts) || 0,
          totalParts: Number(totalParts) || 0,
          adjustedTotal: Number(adjustedTotal) || 0,

          techPercent: Number(techPercent) || 0,
          leadPercent: Number(leadPercent) || 0,
          companyPercent: Number(companyPercent) || 0,

          excludeTechFromParts: !!excludeTechFromParts,
          techPaysAdditionalFee: !!techPaysAdditionalFee,
          leadAdditionalFee: Number(leadAdditionalFee) || 0,
          leadOwnedByCompany: !!leadOwnedByCompany,

          techProfit: Number(techProfit) || 0,
          leadProfit: Number(leadProfit) || 0,
          companyProfitBase: Number(companyProfitBase) || 0,
          companyProfitDisplay: Number(companyProfitDisplay) || 0,

          techBalance: Number(techBalance) || 0,
          leadBalance: Number(leadBalance) || 0,
          companyBalance: Number(companyBalance) || 0,

          sumCheck: Number(sumCheck) || 0,

          // 🔥 NEW PAYMENT TOTALS
         cashTotal,
         creditTotal,
         checkTotal,
         zelleTotal,

          closedAt: isFinalClose ? new Date() : undefined,
          closedByUserId: user.id,
        },
      });

      return { job: updatedJob, closing };
    });

    return res.json(result);
  } catch (err) {
    console.error("closeJob error:", err);
    return res.status(500).json({ error: "Failed to close job" });
  }
}
/* ============================================================
   GET JOBS
============================================================ */
export async function getJobs(req: Request, res: Response) {
  try {
    const jobs = await prisma.job.findMany({
      where: { companyId: req.user!.companyId },
      orderBy: { createdAt: "desc" },
      include: {
        technician: true,
        jobType: true,
        source: true,
        jobStatus: true,
      },
    });
    res.json(jobs);
  } catch (err) {
    console.error("🔥 GET JOBS ERROR:", err);
    res.status(500).json({ error: "Failed to load jobs" });
  }
}

/* ============================================================
   CREATE JOB
============================================================ */
export async function createJob(req: Request, res: Response) {
  try {
    const {
      title,
      description,
      customerName,
      customerPhone,
      customerAddress,
      jobTypeId,
      technicianId,
      scheduledAt,
      status,
      sendSmsToTech,
      sourceId,
    } = req.body;

    const shortId = await generateUniqueShortId();

    const jtName = jobTypeId
      ? await prisma.jobType
          .findUnique({ where: { id: jobTypeId } })
          .then((jt) => jt?.name || "")
      : "";

    const finalTitle =
      title ||
      (customerName
        ? `${customerName}${jtName ? " - " + jtName : ""}`
        : "New Job");

    const job = await prisma.job.create({
      data: {
        shortId,
        title: finalTitle,
        description,
        customerName,
        customerPhone,
        customerAddress,
        jobTypeId: jobTypeId || null,
        technicianId: technicianId || null,
        scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
        status: status || "Accepted",
        sourceId: sourceId || null,
        companyId: req.user!.companyId,
      },
      include: {
        technician: true,
        jobType: true,
        source: true,
        jobStatus: true,
      },
    });

    // --------------------------------------------------------
    // 🔥 DEBUG: SHOW IF SMS SHOULD SEND
    // --------------------------------------------------------
    console.log("📨 createJob(): sendSmsToTech =", sendSmsToTech);
    console.log("📨 technicianId =", technicianId);
    
    if (sendSmsToTech && technicianId) {
      console.log("📨 Calling sendTechSms() now...");
      await sendTechSms(technicianId, job);
      console.log("📨 sendTechSms() finished");
    } else {
      console.log("⚠ SMS NOT SENT: sendSmsToTech=false OR no technicianId");
    }

    return res.json({ message: "Job created", job });
  } catch (err) {
    console.error("🔥 CREATE JOB ERROR:", err);
    res.status(500).json({ error: "Failed to create job" });
  }
}
/* ============================================================
   UPDATE JOB (by shortId)
============================================================ */
export async function updateJobByShortId(req: Request, res: Response) {
  try {
    const shortId = req.params.shortId.toUpperCase();

    const updates = req.body;

    const job = await prisma.job.findFirst({
      where: { shortId, companyId: req.user!.companyId },
    });

    if (!job) return res.status(404).json({ error: "Job not found" });

    const updated = await prisma.job.update({
      where: { id: job.id },
      data: {
        title: updates.title ?? job.title,
        description: updates.description ?? job.description,
        technicianId:
          updates.technicianId !== undefined
            ? updates.technicianId || null
            : job.technicianId,
        scheduledAt:
          updates.scheduledAt !== undefined
            ? updates.scheduledAt
              ? new Date(updates.scheduledAt)
              : null
            : job.scheduledAt,
        status: updates.status ?? job.status,
        jobTypeId:
          updates.jobTypeId !== undefined
            ? updates.jobTypeId || null
            : job.jobTypeId,
        customerName: updates.customerName ?? job.customerName,
        customerPhone: updates.customerPhone ?? job.customerPhone,
        customerAddress: updates.customerAddress ?? job.customerAddress,
        sourceId:
          updates.sourceId !== undefined
            ? updates.sourceId || null
            : job.sourceId,
        statusId:
          updates.statusId !== undefined ? updates.statusId || null : job.statusId,
      },
      include: {
        technician: true,
        jobType: true,
        source: true,
        jobStatus: true,
      },
    });

    return res.json({ message: "Job updated", job: updated });
  } catch (err) {
    console.error("🔥 UPDATE JOB ERROR:", err);
    res.status(500).json({ error: "Failed to update job" });
  }
}

/* ============================================================
   GET JOB (shortId)
============================================================ */
export async function getJobByShortId(req: Request, res: Response) {
  try {
    const job = await prisma.job.findFirst({
      where: {
        shortId: req.params.shortId.toUpperCase(),
        companyId: req.user!.companyId,
      },
      include: {
        technician: true,
        jobType: true,
        source: true,
        jobStatus: true,
        closing: true,
        logs: {
          include: { user: true },
        },

        // ⭐ Needed for EXT + masked dial
        callSessions: {
          orderBy: { createdAt: "desc" },
        },

        // ⭐ Needed for recordings tab
        records: {
          orderBy: { createdAt: "desc" },
        },
      },
    });

    if (!job) return res.status(404).json({ error: "Job not found" });
    res.json(job);
  } catch (err) {
    console.error("🔥 GET JOB ERROR:", err);
    res.status(500).json({ error: "Failed to load job" });
  }
}
/* ============================================================
   TWILIO CREATE / REUSE CALL SESSION (extension)
============================================================ */
async function getOrCreateCallSession(job: any, technicianId: string) {
  const normalizedPhone = normalizePhone(job.customerPhone);
  if (!normalizedPhone) return null;

  // Try to reuse existing session for this job + tech + customer
  const existing = await prisma.jobCallSession.findFirst({
    where: {
      jobId: job.id,
      technicianId,
      customerPhone: normalizedPhone,
    },
  });

  if (existing) return existing;

  // Create new extension (3 digits)
  const ext = Math.floor(100 + Math.random() * 900).toString();

  const session = await prisma.jobCallSession.create({
    data: {
      jobId: job.id,
      technicianId,
      customerPhone: normalizedPhone,
      extension: ext,
      companyId: job.companyId,
    },
  });

  return session;
}

/* ============================================================
   SEND TECH SMS  (honors maskedCalls flag)
============================================================ */
async function sendTechSms(techId: string, job: any) {
console.log("📨 sendTechSms() CALLED for tech:", techId, "job:", job.shortId);
  const tech = await prisma.user.findUnique({ where: { id: techId } });

  if (!tech?.phone) return;
  if (!TWILIO_NUMBER) return;

  const company = await prisma.company.findUnique({
    where: { id: job.companyId },
  });

  if (!company) {
    console.error("❌ Company not found for job");
    return;
  }

  // SAFELY PARSE JSON → CONVERT TO UNKNOWN FIRST → CAST
  const settings: SmsSettings =
    (company.smsSettings as unknown as SmsSettings) || defaultSmsSettings;

  const maskingEnabled = !!tech.maskedCalls;

  // We'll build the SMS off this object
  const jobForSms: any = { ...job };

  let maskedInfo = "";

  // MASKED CALLS → Replace job customerPhone directly
if (maskingEnabled) {
  const session = await getOrCreateCallSession(job, techId);

  if (session && TWILIO_NUMBER) {
    const clean = TWILIO_NUMBER.replace(/^\+1/, "").replace(/[^\d]/g, "");
    jobForSms.customerPhone = `${clean},${session.extension}`;
  }
}

  // Base text uses either real or masked phone depending on maskingEnabled
  const baseText = buildSmsText(jobForSms, settings);
  const finalBody = `${baseText}${maskedInfo}`;

  try {
    await twilioClient.messages.create({
      to: tech.phone,
      from: TWILIO_NUMBER,
      body: finalBody,
    });
  } catch (err) {
    console.error("❌ SMS ERROR:", err);
  }
}

/* ============================================================
   RESEND SMS (shortId)
============================================================ */
export async function resendJobSms(req: Request, res: Response) {
  try {
    const job = await prisma.job.findFirst({
      where: {
        shortId: req.params.shortId.toUpperCase(),
        companyId: req.user!.companyId,
      },
      include: { technician: true, jobType: true, source: true },
    });

    if (!job) return res.status(404).json({ error: "Job not found" });
    if (!job.technicianId)
      return res.status(400).json({ error: "No technician assigned" });

    await sendTechSms(job.technicianId, job);

    res.json({ message: "SMS sent" });
  } catch (err) {
    console.error("🔥 RESEND SMS ERROR:", err);
    res.status(500).json({ error: "Failed to resend SMS" });
  }
}

/* ============================================================
   BUILD SMS BODY (Option A)
============================================================ */
function buildSmsText(job: any, settings: SmsSettings): string {
  const lines: string[] = [];

  const getVal = (key: SmsFieldKey): string => {
    switch (key) {
      case "id":
        return job.shortId || "";
      case "name":
        return job.customerName || "";
      case "phone":
        return job.customerPhone || "";
      case "address":
        return job.customerAddress || "";
      case "jobType":
        return job.jobType?.name || "";
      case "notes":
        return job.description || "";
      case "appointment":
        return job.scheduledAt
          ? new Date(job.scheduledAt).toLocaleString("en-US", {
              dateStyle: "short",
              timeStyle: "short",
            })
          : "";
      case "leadSource":
        return job.source?.name || "";
      default:
        return "";
    }
  };

  const getLabel = (key: SmsFieldKey): string => {
    switch (key) {
      case "id":
        return "Job ID";
      case "name":
        return "Name";
      case "phone":
        return "Phone";
      case "address":
        return "Address";
      case "jobType":
        return "Job";
      case "notes":
        return "Notes";
      case "appointment":
        return "APP";
      case "leadSource":
        return "Source";
      default:
        return "";
    }
  };

  for (const key of settings.order) {
    if (!settings.show[key]) continue;

    const value = getVal(key);

    if (settings.showLabel[key]) {
      lines.push(`${getLabel(key)}: ${value}`);
    } else {
      lines.push(value);
    }
  }

  return lines.join("\n").trim();
}

/* ============================================================
   reopen closed job (ADMIN ONLY)
============================================================ */
export async function reopenJob(req: Request, res: Response) {
  try {
    const { shortId } = req.params;
    const user = req.user!;

    // Only admin can reopen
    if (user.role !== "admin") {
      return res.status(403).json({ error: "Only admin can reopen jobs." });
    }

    const job = await prisma.job.findUnique({
      where: { shortId },
      include: { closing: true },
    });

    if (!job) return res.status(404).json({ error: "Job not found" });

    // Must be closed already
    if (!job.isClosingLocked) {
      return res.status(400).json({ error: "Job is not closed." });
    }

    // ✅ DO NOT change job status
    // ✅ DO NOT delete jobClosing
    // Just unlock the job and allow editing again
    const updated = await prisma.job.update({
      where: { id: job.id },
      data: {
        isClosingLocked: false,
        closedAt: null, // optional: cleanup field so UI knows it's open
        // statusId: DO NOT TOUCH
      },
    });

    return res.json({
      message: "Job reopened — closing data preserved",
      job: updated,
    });
  } catch (err) {
    console.error("REOPEN JOB ERROR", err);
    return res.status(500).json({ error: "Failed to reopen job" });
  }
}
/* ============================================================
   GET CALL RECORDINGS (LIVE FROM TWILIO)
============================================================ */
export async function getJobRecordings(req: Request, res: Response) {
  try {
    const job = await prisma.job.findFirst({
      where: {
        shortId: req.params.shortId.toUpperCase(),
        companyId: req.user!.companyId,
      },
      include: {
        records: true, // stores callSid for each call event
      },
    });

    if (!job) {
      return res.status(404).json({ error: "Job not found" });
    }

    const results: any[] = [];

    for (const rec of job.records) {
      try {
        // 1️⃣ Fetch call info
        const call = await twilioClient.calls(rec.callSid).fetch();

        // 2️⃣ Fetch recordings for this call
        const twilioRecordings = await twilioClient
          .calls(rec.callSid)
          .recordings
          .list();

        const formattedRecordings = [];

        for (const r of twilioRecordings) {
          const mp3Url =
            `https://api.twilio.com/2010-04-01/Accounts/${process.env.TWILIO_ACCOUNT_SID}/Recordings/${r.sid}.mp3`;

          // 3️⃣ Try loading transcription
          let transcript = "";
          try {
            const transList = await twilioClient
              .recordings(r.sid)
              .transcriptions
              .list();

            if (transList.length > 0) {
              transcript = transList[0].transcriptionText || "";
            }
          } catch (err) {
            // ignore if none
          }

          formattedRecordings.push({
            recordingSid: r.sid,
            duration: r.duration,
            url: mp3Url,
            transcript,
          });
        }

        results.push({
          id: rec.id,
          callSid: rec.callSid,
          createdAt: rec.createdAt,

          // ⭐ Caller IDs from Twilio
          from: call.from,
          to: call.to,

          // ⭐ Call status
          status: call.status, // completed / busy / failed / no-answer / etc.

          recordings: formattedRecordings,
        });
      } catch (err) {
        console.error("❌ Twilio fetch error", err);
      }
    }

    return res.json(results);
  } catch (err) {
    console.error("🔥 getJobRecordings error", err);
    return res.status(500).json({ error: "Failed to load recordings" });
  }
}