import { Router } from "express";

import {
  createJob,
  getJobs,
  getJobByShortId,
  updateJobByShortId,
  resendJobSms,
  closeJob,
  reopenJob,
  parseJobFromText,
  createJobFromParsed,
  refreshExtension
} from "./job.controller";

import { authMiddleware } from "../../middleware/auth";
import { tenantMiddleware } from "../../middleware/tenant";
import { getJobRecordings } from "../twilio/voice.controller";

const router = Router();

/* AI parse */
router.post("/parse", parseJobFromText);
router.post("/create-from-parse", createJobFromParsed);

/* Refresh extension — MUST match frontend */
router.post("/short/:shortId/refresh-extension", authMiddleware, refreshExtension);

/* Jobs listing + creating */
router.get("/", authMiddleware, getJobs);
router.post("/", authMiddleware, createJob);

router.get("/jobs/short/:shortId/recordings", getJobRecordings);

/* Job details */
router.get("/short/:shortId", authMiddleware, getJobByShortId);
router.put("/short/:shortId", authMiddleware, updateJobByShortId);

/* Recordings */
router.get("/short/:shortId/recordings", authMiddleware, tenantMiddleware, getJobRecordings);

/* SMS */
router.post("/short/:shortId/resend-sms", authMiddleware, resendJobSms);

/* Closing */
router.post("/short/:shortId/close", authMiddleware, closeJob);

/* Reopen job */
router.post("/short/:shortId/reopen", authMiddleware, reopenJob);

export default router;