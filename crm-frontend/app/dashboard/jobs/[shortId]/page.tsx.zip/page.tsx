"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { toast } from "sonner";
import GoogleAddressInput from "@/components/GoogleAddressInput";

/* ---- TYPES ---- */

interface JobStatus {
  id: string;
  name: string;
  order: number;
  active: boolean;
}

interface Job {
  id: string;
  shortId?: string;
  title: string;
  description?: string | null;
  customerName?: string | null;
  customerPhone?: string | null;
  customerAddress?: string | null;

  jobType?: { id: string; name: string } | null;
  technician?: { id: string; name: string; phone?: string | null } | null;

  jobTypeId?: string | null;
  technicianId?: string | null;

  scheduledAt?: string | null;

  status?: string | null;
  statusId?: string | null;

  jobStatus?: { id: string; name: string } | null;

  /* closing info */
  isClosingLocked?: boolean;
  closedAt?: string | null;
  closedByUser?: { id: string; name: string; role: string } | null;

  createdAt: string;

  source?: { id: string; name: string } | null;
  sourceId?: string | null;

  logs?: {
    id: string;
    createdAt: string;
    type: string;
    text: string;
    user?: {
      id: string;
      name: string;
      role: string;
    } | null;
  }[];

  /* ---- NEW: CALL SESSIONS ---- */
  callSessions?: {
    id?: string;
    extension: string;
    customerPhone: string;
    createdAt: string;
  }[];  recordings?: {
    id: string;
    callSid: string;
    from: string;
    to: string;
    url: string;
    createdAt: string;
  }[];
}

interface JobType {
  id: string;
  name: string;
}

interface Tech {
  id: string;
  name: string;
  phone?: string | null;
}

/* ---- FORMULA ENGINE TYPES (v1.4) ---- */

type PaymentMethod = "cash" | "credit" | "check" | "zelle";
type Collector = "tech" | "company" | "lead";

interface PaymentRow {
  id: number;
  payment: PaymentMethod;
  collectedBy: Collector;
  amount: string; // text input
  ccFeePct: string; // text input for %
}

interface FormulaResult {
  totalAmount: number;
  cashTotal: number;
  creditTotal: number;
  checkTotal: number;
  zelleTotal: number;

  techParts: number;
  leadParts: number;
  companyParts: number;
  totalParts: number;

  totalCcFee: number;
  additionalFee: number;
  adjustedTotal: number;

  techPercent: number;
  leadPercent: number;
  companyPercent: number;

  techProfit: number; // visual profit (with parts if enabled)
  leadProfit: number;
  companyProfit: number;

  techBalance: number;
  leadBalance: number;
  companyBalance: number;

  sumCheck: number;
}

export default function JobDetailsPage() {
  const params = useParams() as { shortId: string };
  const shortId = params.shortId;
  const router = useRouter();

  const base = process.env.NEXT_PUBLIC_API_URL;

  /* JOB + META STATE */

  const [job, setJob] = useState<Job | null>(null);
  const [editableJob, setEditableJob] = useState<any>(null);
  const [dirty, setDirty] = useState(false);

  const [jobTypes, setJobTypes] = useState<JobType[]>([]);
  const [techs, setTechs] = useState<Tech[]>([]);
  const [statuses, setStatuses] = useState<JobStatus[]>([]);
  const [leadSources, setLeadSources] = useState<{ id: string; name: string }[]>(
    []
  );

  const [tab, setTab] = useState<"overview" | "log" | "recordings">("overview");
  const [saving, setSaving] = useState(false);

  /* v1.4 FORMULA ENGINE STATE (local to job page) */

  // Payments
  const [payments, setPayments] = useState<PaymentRow[]>([
    {
      id: 1,
      payment: "cash",
      collectedBy: "tech",
      amount: "",
      ccFeePct: "0",
    },
  ]);

  // Commission %
  const [techPercent, setTechPercent] = useState("30");
  const [leadPercent, setLeadPercent] = useState("50");
  const [companyPercent, setCompanyPercent] = useState("20");

  // Invoice number
  const [invoiceNumberState, setInvoiceNumberState] = useState("");

  // Parts
  const [techParts, setTechParts] = useState("0");
  const [leadParts, setLeadParts] = useState("0");
  const [companyParts, setCompanyParts] = useState("0");

  // Flags
  const [includePartsInProfit, setIncludePartsInProfit] = useState(true);
  const [excludeTechFromParts, setExcludeTechFromParts] = useState(false);
  const [disableAutoAdjust, setDisableAutoAdjust] = useState(false);

  // Additional lead fee
  const [leadAdditionalFee, setLeadAdditionalFee] = useState("0");
  const [techPaysAdditionalFee, setTechPaysAdditionalFee] = useState(false);

  // Lead owned by company (visual only)
  const [leadOwnedByCompany, setLeadOwnedByCompany] = useState(false);

  // Single calculation result for this job
  const [result, setResult] = useState<FormulaResult | null>(null);

async function refreshExt() {
    console.log("🔵 RefreshExt → sending request to:", `${base}/jobs/short/${shortId}/refresh-extension`);
  try {
    const res = await fetch(
      `${base}/jobs/short/${shortId}/refresh-extension`,
      {
        method: "POST",
        credentials: "include",
      }
    );
console.log("🟣 RefreshExt response status:", res.status);

    const data = await res.json().catch(() => null);
    console.log("🟣 RefreshExt response body:", data);

    if (!res.ok) {
      toast.error("Failed to refresh extension");
      return;
    }

    toast.success("Extension refreshed");
    loadJob(); // reload job to show new extension
  } catch (err) {
        console.log("🔴 refreshExt ERROR:", err);
    toast.error("Error refreshing extension");
  }
}

  // closing job handle
  async function handleCloseJob(result: FormulaResult, invoiceNumber?: string) {
    try {
      const base = process.env.NEXT_PUBLIC_API_URL;

      const payload = {
  invoiceNumber: invoiceNumber || "",
  payments: payments,

  totalAmount: result.totalAmount,
  totalCcFee: result.totalCcFee,
  techParts: result.techParts,
  leadParts: result.leadParts,
  companyParts: result.companyParts,
  totalParts: result.totalParts,
  adjustedTotal: result.adjustedTotal,

  techPercent: result.techPercent,
  leadPercent: result.leadPercent,
  companyPercent: result.companyPercent,

  excludeTechFromParts,
  techPaysAdditionalFee,
  leadAdditionalFee,
  leadOwnedByCompany,

  techProfit: result.techProfit,
  leadProfit: result.leadProfit,
  companyProfitBase: 0,
  companyProfitDisplay: result.companyProfit,

  techBalance: result.techBalance,
  leadBalance: result.leadBalance,
  companyBalance: result.companyBalance,

  sumCheck: result.sumCheck,

  // 🔥 REQUIRED FOR BACKEND TO UPDATE STATUS
  statusId: editableJob.statusId,  
};

      const res = await fetch(`${base}/jobs/short/${shortId}/close`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        console.error(data);
        return toast.error(data.error || "Failed to close job");
      }

      toast.success("Job closed & saved");
    } catch (err) {
      console.error(err);
      toast.error("Failed to close job");
    }
  }

  /* LOAD JOB / SUPPORT DATA */

  useEffect(() => {
    loadJob();
    loadJobTypes();
    loadTechnicians();
    loadStatuses();
    loadLeadSources();
    loadRecordings();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shortId]);

  const loadJob = async () => {
  try {
    const res = await fetch(`${base}/jobs/short/${shortId}`, {
      credentials: "include",
    });

    if (res.status === 401) {
      router.push("/login");
      return;
    }

    const data = await res.json();

    if (!res.ok) {
      toast.error(data.error || "Failed to load job");
      return;
    }

    setJob(data);
    setEditableJob(data);
    setDirty(false);

    if (data.closing) {
      const c = data.closing;

      if (Array.isArray(c.payments) && c.payments.length > 0) {
        setPayments(c.payments);
      }

      setTechParts(String(c.techParts ?? 0));
      setLeadParts(String(c.leadParts ?? 0));
      setCompanyParts(String(c.companyParts ?? 0));

      setTechPercent(String(c.techPercent ?? 0));
      setLeadPercent(String(c.leadPercent ?? 0));
      setCompanyPercent(String(c.companyPercent ?? 0));

      setLeadAdditionalFee(String(c.leadAdditionalFee ?? 0));
      setTechPaysAdditionalFee(Boolean(c.techPaysAdditionalFee));
      setExcludeTechFromParts(Boolean(c.excludeTechFromParts));

      setIncludePartsInProfit(true);

      setInvoiceNumberState(c.invoiceNumber ?? "");

      setResult({
        totalAmount: Number(c.totalAmount),
        cashTotal: 0,
        creditTotal: 0,
        checkTotal: 0,
        zelleTotal: 0,

        techParts: Number(c.techParts),
        leadParts: Number(c.leadParts),
        companyParts: Number(c.companyParts),
        totalParts: Number(c.totalParts),

        totalCcFee: Number(c.totalCcFee),
        additionalFee: Number(c.leadAdditionalFee),
        adjustedTotal: Number(c.adjustedTotal),

        techPercent: Number(c.techPercent),
        leadPercent: Number(c.leadPercent),
        companyPercent: Number(c.companyPercent),

        techProfit: Number(c.techProfit),
        leadProfit: Number(c.leadProfit),
        companyProfit: Number(c.companyProfitDisplay),

        techBalance: Number(c.techBalance),
        leadBalance: Number(c.leadBalance),
        companyBalance: Number(c.companyBalance),

        sumCheck: Number(c.sumCheck),
      });
    }
  } catch (err) {
    toast.error("Failed to load job");
  }
};

async function loadRecordings() {
  try {
    const res = await fetch(`${base}/jobs/short/${shortId}/recordings`, {
      credentials: "include",
    });
    const data = await res.json();

    if (res.ok) {
      setJob((prev) => ({
        ...prev!,
        recordings: data,
      }));
    }
  } catch {}
}

  const loadJobTypes = async () => {
    try {
      const res = await fetch(`${base}/job-types`, { credentials: "include" });
      setJobTypes(await res.json());
    } catch {}
  };

  const loadTechnicians = async () => {
    try {
      const res = await fetch(`${base}/users`, { credentials: "include" });
      const data = await res.json();
      setTechs(data.filter((u: any) => u.role === "technician"));
    } catch {}
  };
    const loadLeadSources = async () => {
    try {
      const res = await fetch(`${base}/lead-sources`, {
        credentials: "include",
      });
      setLeadSources(await res.json());
    } catch {}
  };

  const loadStatuses = async () => {
    try {
      const res = await fetch(`${base}/job-status`, { credentials: "include" });
      setStatuses(await res.json());
    } catch {}
  };

  /* GENERIC EDIT HANDLER */

  function setField(field: string, value: any) {
    setEditableJob((prev: any) => ({
      ...prev,
      [field]: value,
    }));
    setDirty(true);
  }

  async function saveChanges() {
    if (!editableJob) return;

    setSaving(true);
    try {
      const res = await fetch(`${base}/jobs/short/${editableJob.shortId}`, {
        method: "PUT",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(editableJob),
      });

      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Failed to save");
        return;
      }

      setJob(data.job);
      setEditableJob(data.job);
      setDirty(false);
      toast.success("Saved");
    } catch {
      toast.error("Saving failed");
    } finally {
      setSaving(false);
    }
  }

  if (!job || !editableJob) {
    return <div className="p-6">Loading job...</div>;
  }

  const displayId = job.shortId || job.id.slice(0, 8);

  // TEMP ADMIN OVERRIDE (replace later when backend sends user role)
const isAdmin = job.closedByUser?.role === "admin" || true;

  /* STATUS → SHOW CLOSING PANEL? (based on current dropdown value) */
  const currentStatusId: string | undefined =
    editableJob.statusId ?? job.statusId ?? undefined;

  const currentStatusName: string | undefined =
    statuses.find((s) => s.id === currentStatusId)?.name ??
    editableJob.jobStatus?.name ??
    editableJob.status ??
    job.jobStatus?.name ??
    job.status ??
    undefined;

  const showClosingPanel =
    currentStatusName === "Closed" || currentStatusName === "Pending Close";

  const editingLocked = job.isClosingLocked && job.isClosingLocked === true;

  /* ---------------- v1.4 FORMULA ENGINE HELPERS ---------------- */

  function getCollectorOptions(payment: PaymentMethod): Collector[] {
    switch (payment) {
      case "cash":
        return [];
      case "credit":
        return ["tech", "company", "lead"];
      case "check":
        return ["company", "lead"];
      case "zelle":
        return ["company", "lead"];
      default:
        return [];
    }
  }

  function addPaymentRow() {
    setPayments((prev) => [
      ...prev,
      {
        id: prev.length ? prev[prev.length - 1].id + 1 : 1,
        payment: "cash",
        collectedBy: "tech",
        amount: "",
        ccFeePct: "0",
      },
    ]);
  }

  function removePaymentRow(id: number) {
    setPayments((prev) => prev.filter((p) => p.id !== id));
  }

  function updatePayment(id: number, field: keyof PaymentRow, value: string) {
    setPayments((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              [field]: value,
              ...(field === "payment"
                ? {
                    collectedBy: value === "cash" ? "tech" : "company",
                    ccFeePct: value === "credit" ? p.ccFeePct : "0",
                  }
                : {}),
            }
          : p
      )
    );
  }

  function handlePercentChange(
    field: "tech" | "lead" | "company",
    value: string
  ) {
    if (value === "") {
      if (field === "tech") setTechPercent("");
      if (field === "lead") setLeadPercent("");
      if (field === "company") setCompanyPercent("");
      return;
    }

    const num = Number(value);
    if (isNaN(num)) return;

    if (disableAutoAdjust) {
      if (field === "tech") setTechPercent(value);
      if (field === "lead") setLeadPercent(value);
      if (field === "company") setCompanyPercent(value);
      return;
    }

    if (field === "tech") {
      setTechPercent(value);
      return;
    }

    if (field === "lead") {
      setLeadPercent(value);
      const newCompany = 100 - (Number(techPercent) || 0) - num;
      setCompanyPercent(String(newCompany));
      return;
    }

    if (field === "company") {
      setCompanyPercent(value);
      const newLead = 100 - (Number(techPercent) || 0) - num;
      setLeadPercent(String(newLead));
    }
  }

  function normalizePercent(field: "tech" | "lead" | "company") {
    let val =
      field === "tech"
        ? techPercent
        : field === "lead"
        ? leadPercent
        : companyPercent;

    if (val === "" || val === null) val = "0";
    const num = Number(val);

    const formatted =
      Math.abs(num % 1) < 0.00001 ? String(num) : num.toFixed(2);

    if (disableAutoAdjust) {
      if (field === "tech") setTechPercent(formatted);
      if (field === "lead") setLeadPercent(formatted);
      if (field === "company") setCompanyPercent(formatted);
      return;
    }

    if (field === "tech") {
      setTechPercent(formatted);
      return;
    }

    if (field === "lead") {
      setLeadPercent(formatted);
      const newCompany = 100 - (Number(techPercent) || 0) - num;
      const formattedCompany =
        Math.abs(newCompany % 1) < 0.00001
          ? String(newCompany)
          : newCompany.toFixed(2);
      setCompanyPercent(formattedCompany);
      return;
    }

    if (field === "company") {
      setCompanyPercent(formatted);
      const newLead = 100 - (Number(techPercent) || 0) - num;
      const formattedLead =
        Math.abs(newLead % 1) < 0.00001 ? String(newLead) : newLead.toFixed(2);
      setLeadPercent(formattedLead);
    }
  }

  /* CORE CALCULATION (v1.4) */

  function calculateSplit() {
    if (!payments.length) return;

    // Totals by payment
    let totalAmount = 0;
    let totalCcFee = 0;

    let amountHeldByTech = 0;
    let amountHeldByCompany = 0;
    let amountHeldByLead = 0;

    let cashTotal = 0;
    let creditTotal = 0;
    let checkTotal = 0;
    let zelleTotal = 0;

    payments.forEach((p) => {
      const amt = Number(p.amount) || 0;
      totalAmount += amt;

      if (p.payment === "cash") {
        cashTotal += amt;
        amountHeldByTech += amt; // cash always tech
      } else {
        if (p.payment === "credit") creditTotal += amt;
        if (p.payment === "check") checkTotal += amt;
        if (p.payment === "zelle") zelleTotal += amt;

        if (p.collectedBy === "tech") amountHeldByTech += amt;
        if (p.collectedBy === "company") amountHeldByCompany += amt;
        if (p.collectedBy === "lead") amountHeldByLead += amt;
      }

      // CC fee (only credit, % per row)
      if (p.payment === "credit") {
        const pct = Number(p.ccFeePct) || 0;
        totalCcFee += (amt * pct) / 100;
      }
    });

    // Parts
    const techPartsVal = Number(techParts) || 0;
    const leadPartsVal = Number(leadParts) || 0;
    const companyPartsVal = Number(companyParts) || 0;
    const totalParts = techPartsVal + leadPartsVal + companyPartsVal;

    // Percentages
    const tPct = (Number(techPercent) || 0) / 100;
    const lPct = (Number(leadPercent) || 0) / 100;
    const cPct = (Number(companyPercent) || 0) / 100;

    // Adjusted revenue
    const adjustedTotal = totalAmount - totalParts - totalCcFee;

    // Base profit (no parts yet)
    let techProfitBase = adjustedTotal * tPct;
    let leadProfitBase = adjustedTotal * lPct;
    let companyProfitBase = adjustedTotal * cPct;

    // CC fee reimbursements
    payments.forEach((p) => {
      if (p.payment !== "credit") return;
      const amt = Number(p.amount) || 0;
      const pct = Number(p.ccFeePct) || 0;
      const fee = (amt * pct) / 100;
      if (!fee) return;

      if (p.collectedBy === "tech") techProfitBase += fee;
      else if (p.collectedBy === "lead") leadProfitBase += fee;
      else companyProfitBase += fee;
    });

    // Additional lead fee
    const addFee = Number(leadAdditionalFee) || 0;
    if (addFee !== 0) {
      leadProfitBase += addFee;
      if (techPaysAdditionalFee) techProfitBase -= addFee;
      else companyProfitBase -= addFee;
    }

    // VISUAL profits (parts optional)
    let techProfitDisplay = techProfitBase;
    let leadProfitDisplay = leadProfitBase;
    let companyProfitDisplayReal = companyProfitBase;

    if (includePartsInProfit) {
      techProfitDisplay += techPartsVal;
      leadProfitDisplay += leadPartsVal;
      companyProfitDisplayReal += companyPartsVal;
    }

    const companyProfitDisplay = leadOwnedByCompany
      ? companyProfitDisplayReal + leadProfitBase
      : companyProfitDisplayReal;

    // BALANCES
    let techPartsCharge = techPartsVal;
    let leadPartsCharge = leadPartsVal;
    let companyPartsCharge = companyPartsVal;

    // v1.1: Exclude tech from paying lead/company parts
    if (excludeTechFromParts) {
      // Tech only responsible for his own parts
      techPartsCharge = techPartsVal;

      // Lead/company still get their parts reimbursed → they keep partsCharge
      leadPartsCharge = leadPartsVal;
      companyPartsCharge = companyPartsVal;
    }

    const techBalance =
      amountHeldByTech - techProfitBase - techPartsCharge;

    const leadBalance =
      amountHeldByLead - leadProfitBase - leadPartsCharge;

    const companyBalance =
      amountHeldByCompany - companyProfitBase - companyPartsCharge;

    const totalProfitBase =
      techProfitBase + leadProfitBase + companyProfitBase;

    const sumCheck = totalProfitBase - adjustedTotal;

    const newResult: FormulaResult = {
      totalAmount,
      cashTotal,
      creditTotal,
      checkTotal,
      zelleTotal,

      techParts: techPartsVal,
      leadParts: leadPartsVal,
      companyParts: companyPartsVal,
      totalParts,

      totalCcFee,
      additionalFee: addFee,
      adjustedTotal,

      techPercent: Number(techPercent) || 0,
      leadPercent: Number(leadPercent) || 0,
      companyPercent: Number(companyPercent) || 0,

      techProfit: techProfitDisplay,
      leadProfit: leadProfitDisplay,
      companyProfit: companyProfitDisplay,

      techBalance,
      leadBalance,
      companyBalance,

      sumCheck,
    };

    setResult(newResult);
    return newResult;
  }

  function handleCloseJobClick() {
    const r = calculateSplit();
    if (!r) return;
    toast.success("Calculated closing split (not saved yet).");
  }

  /* --------------------------- RENDER --------------------------- */

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      {/* HEADER */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-semibold">Job #{displayId}</h1>
          <p className="text-gray-500 text-sm">
            Created: {new Date(job.createdAt).toLocaleString()}
          </p>
        </div>

        <div className="flex justify-start items-center gap-3">
          <button
            onClick={() => router.back()}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-800 rounded"
          >
            Back
          </button>

          <button
            onClick={saveChanges}
            disabled={!dirty || saving}
            className={`px-4 py-2 rounded shadow text-white ${
              dirty ? "bg-blue-600" : "bg-gray-400 cursor-not-allowed"
            }`}
          >
            {saving ? "Saving…" : "Save Changes"}
          </button>
        </div>
      </div>

      {/* TABS */}
      <div className="flex gap-4 border-b pb-2">
        <button
          className={`pb-2 ${
            tab === "overview" ? "border-b-2 border-blue-600" : ""
          }`}
          onClick={() => setTab("overview")}
        >
          Overview
        </button>
        <button
          className={`pb-2 ${
            tab === "log" ? "border-b-2 border-blue-600" : ""
          }`}
          onClick={() => setTab("log")}
        >
          Log
        </button>
        <button
          className={`pb-2 ${
            tab === "recordings" ? "border-b-2 border-blue-600" : ""
          }`}
          onClick={() => setTab("recordings")}
        >
          Recordings
        </button>
      </div>
            {/* OVERVIEW TAB */}
      {tab === "overview" && (
        <div className="space-y-6">
          {/* CUSTOMER INFO */}
          <div className="border rounded p-4 space-y-3 bg-gray-50 dark:bg-gray-900">
            <h2 className="font-semibold text-lg mb-2">Customer Information</h2>

            <Editable
              label="Name"
              value={editableJob.customerName || ""}
              onChange={(v) => setField("customerName", v)}
            />

            <Editable
  label="Phone"
  value={editableJob.customerPhone || ""}
  onChange={(v) => setField("customerPhone", v)}
/>

{job.callSessions && job.callSessions.length > 0 && (
  <div className="mt-2">
    <p className="text-xs text-gray-500">
      Tech Extension: <b>{job.callSessions[0].extension}</b>
    </p>

    <p className="text-xs text-gray-500 mt-1">
      Masked Dial:{" "}
      <span className="font-mono">
        {`${(editableJob.customerPhone || "")
          .replace(/^\+1/, "")
          .replace(/[^\d]/g, "")},${job.callSessions[0].extension}#`}
      </span>
    </p>

    <button
      onClick={refreshExt}
      className="text-blue-600 text-xs underline mt-1"
    >
      Refresh Extension
    </button>
  </div>
)}
            <div>
              <label className="block text-sm font-medium">Address</label>
              <GoogleAddressInput
                value={editableJob.customerAddress || ""}
                onChange={(v) => setField("customerAddress", v)}
              />
            </div>

            {/* JOB TYPE */}
            <div>
              <label className="block text-sm font-medium">Job Type</label>
              <select
                className="mt-1 w-full border rounded p-2"
                value={editableJob.jobTypeId || ""}
                onChange={(e) => setField("jobTypeId", e.target.value)}
              >
                <option value="">Select type</option>
                {jobTypes.map((jt) => (
                  <option key={jt.id} value={jt.id}>
                    {jt.name}
                  </option>
                ))}
              </select>
            </div>

            <Editable
              textarea
              label="Description / Notes"
              value={editableJob.description || ""}
              onChange={(v) => setField("description", v)}
            />
          </div>

          {/* TECH + STATUS + SOURCE */}
          <div className="border rounded p-4 space-y-4 bg-white dark:bg-gray-900">
            {/* Lead Source */}
            <div>
              <label className="block text-sm font-medium">Lead Source</label>
              <select
                className="mt-1 w-full border rounded p-2"
                value={editableJob.sourceId || ""}
                onChange={(e) => setField("sourceId", e.target.value)}
              >
                <option value="">Select source</option>
                {leadSources.map((src) => (
                  <option key={src.id} value={src.id}>
                    {src.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Technician */}
            <div>
              <label className="block text-sm font-medium">Technician</label>

              <div className="flex items-center gap-2">
                <select
                  className="border rounded p-2 flex-1"
                  value={editableJob.technicianId || ""}
                  onChange={(e) => setField("technicianId", e.target.value)}
                >
                  <option value="">Unassigned</option>
                  {techs.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} {t.phone ? `(${t.phone})` : ""}
                    </option>
                  ))}
                </select>

                <button
                  onClick={async () => {
                    const res = await fetch(
                      `${base}/jobs/short/${job.shortId}/resend-sms`,
                      { method: "POST", credentials: "include" }
                    );
                    res.ok ? toast.success("SMS sent") : toast.error("Failed");
                  }}
                  className="px-4 py-2 bg-blue-600 text-white rounded"
                >
                  Resend SMS
                </button>
              </div>
                {/* ⭐ Tech Extension Info */}
            </div>

            {/* Status */}
            <div>
              <label className="block text-sm font-medium">Status</label>
              <select
                className="mt-1 w-full border rounded p-2"
                value={editableJob.statusId || ""}
                onChange={(e) => setField("statusId", e.target.value)}
              >
                <option value="">Select Status</option>
                {statuses.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Appointment */}
            <div>
              <label className="block text-sm font-medium">Appointment</label>
              <input
                type="datetime-local"
                className="mt-1 w-full border rounded p-2"
                value={
                  editableJob.scheduledAt
                    ? editableJob.scheduledAt.slice(0, 16)
                    : ""
                }
                onChange={(e) => setField("scheduledAt", e.target.value)}
              />
            </div>
          </div>

          {/* ----------------- CLOSING PANEL ----------------- */}
          {showClosingPanel && (
            <div className="border rounded p-4 bg-white space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold">
                    Job Closing – Payment & Split
                  </h2>
                  <p className="text-sm text-gray-500">
                    Status: <b>{currentStatusName}</b>
                  </p>
                </div>
                {editingLocked && (
                  <span className="text-xs text-red-500 font-semibold">
                    Locked – only admin can modify.
                  </span>
                )}
              </div>
{editingLocked && (
  <button
    onClick={async () => {

      const res = await fetch(
        `${base}/jobs/short/${shortId}/reopen`,
        {
          method: "POST",
          credentials: "include"
        }
      );

      const data = await res.json();
      if (!res.ok) return toast.error(data.error || "Failed to reopen job");

      toast.success("Job reopened");
      router.refresh();  // reload page
    }}
    className="px-3 py-1 text-xs bg-red-600 text-white rounded ml-4"
  >
    Reopen Job
  </button>
)}
{/* LOCK WRAPPER STARTS AFTER BUTTON */}
              <div
                className={
                  editingLocked ? "opacity-50 pointer-events-none" : ""
                }
              >
                <div className="grid md:grid-cols-2 gap-4 mt-4">
                  {/* LEFT: PAYMENT BLOCKS */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-semibold">
                        Payment Blocks (Multi-Payment)
                      </h3>
                      <button
                        type="button"
                        onClick={addPaymentRow}
                        className="px-2 py-1 text-xs bg-gray-200 hover:bg-gray-300 rounded"
                      >
                        + Add Payment
                      </button>
                    </div>

                    <div className="space-y-3">
                      {payments.map((p) => {
                        const collectors = getCollectorOptions(p.payment);
                        return (
                          <div
                            key={p.id}
                            className="relative grid grid-cols-5 gap-2 border rounded p-2 bg-gray-50 text-xs"
                          >
                            {/* REMOVE */}
                            <button
                              type="button"
                              onClick={() => removePaymentRow(p.id)}
                              className="absolute top-1 right-1 text-red-600 text-[10px] font-bold"
                            >
                              ✕
                            </button>

                            {/* Method */}
                            <div>
                              <label className="block text-[10px] mb-1">
                                Method
                              </label>
                              <select
                                className="border rounded px-1 py-1 w-full text-xs bg-white"
                                value={p.payment}
                                onChange={(e) =>
                                  updatePayment(p.id, "payment", e.target.value)
                                }
                              >
                                <option value="cash">Cash</option>
                                <option value="credit">Credit</option>
                                <option value="check">Check</option>
                                <option value="zelle">Zelle</option>
                              </select>
                            </div>

                            {/* Collected By */}
                            <div>
                              {p.payment !== "cash" ? (
                                <>
                                  <label className="block text-[10px] mb-1">
                                    Collected By
                                  </label>
                                  <select
                                    className="border rounded px-1 py-1 w-full text-xs bg-white"
                                    value={p.collectedBy}
                                    onChange={(e) =>
                                      updatePayment(
                                        p.id,
                                        "collectedBy",
                                        e.target.value
                                      )
                                    }
                                  >
                                    {collectors.map((c) => (
                                      <option key={c} value={c}>
                                        {c === "tech"
                                          ? "Technician"
                                          : c === "lead"
                                          ? "Lead Source"
                                          : "Company"}
                                      </option>
                                    ))}
                                  </select>
                                </>
                              ) : (
                                <div className="text-[10px] text-gray-400 mt-4">
                                  Cash → Technician
                                </div>
                              )}
                            </div>

                            {/* Amount */}
                            <div>
                              <label className="block text-[10px] mb-1">
                                Amount ($)
                              </label>
                              <input
                                className="border rounded px-1 py-1 w-full text-xs bg-white"
                                value={p.amount}
                                onChange={(e) =>
                                  updatePayment(p.id, "amount", e.target.value)
                                }
                              />
                            </div>

                            {/* CC Fee */}
                            <div>
                              {p.payment === "credit" ? (
                                <>
                                  <label className="block text-[10px] mb-1">
                                    CC Fee %
                                  </label>
                                  <input
                                    className="border rounded px-1 py-1 w-full text-xs bg-white"
                                    value={p.ccFeePct}
                                    onChange={(e) =>
                                      updatePayment(
                                        p.id,
                                        "ccFeePct",
                                        e.target.value
                                      )
                                    }
                                  />
                                </>
                              ) : (
                                <div className="text-[10px] text-gray-400 mt-4">
                                  No CC Fee
                                </div>
                              )}
                            </div>

                            <div className="text-[10px] text-gray-400 flex items-center">
                              Payment #{p.id}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* RIGHT SIDE */}
                  <div className="space-y-3">
                    {/* Percentages */}
                    <div className="border rounded p-3 bg-gray-50">
                      <h3 className="text-xs font-semibold mb-2">
                        Percentages
                      </h3>

                      <div className="grid grid-cols-3 gap-3">
                        {/* Tech % */}
                        <div>
                          <label className="block text-[10px] mb-1">
                            Tech %
                          </label>
                          <input
                            className="border rounded px-1 py-1 w-full text-xs bg-white"
                            value={techPercent}
                            onChange={(e) =>
                              handlePercentChange("tech", e.target.value)
                            }
                            onBlur={() => normalizePercent("tech")}
                          />
                        </div>

                        {/* Lead % */}
                        <div>
                          <label className="block text-[10px] mb-1">
                            Lead %
                          </label>
                          <input
                            className="border rounded px-1 py-1 w-full text-xs bg-white"
                            value={leadPercent}
                            onChange={(e) =>
                              handlePercentChange("lead", e.target.value)
                            }
                            onBlur={() => normalizePercent("lead")}
                          />
                          <p className="text-[9px] text-gray-400 italic">
                            auto-adjusted
                          </p>
                        </div>

                        {/* Company % */}
                        <div>
                          <label className="block text-[10px] mb-1">
                            Company %
                          </label>
                          <input
                            className="border rounded px-1 py-1 w-full text-xs bg-white"
                            value={companyPercent}
                            onChange={(e) =>
                              handlePercentChange("company", e.target.value)
                            }
                            onBlur={() => normalizePercent("company")}
                          />
                          <p className="text-[9px] text-gray-400 italic">
                            auto-adjusted
                          </p>
                        </div>
                      </div>

                      <label className="inline-flex items-center gap-2 mt-2 text-[11px]">
                        <input
                          type="checkbox"
                          checked={disableAutoAdjust}
                          onChange={(e) =>
                            setDisableAutoAdjust(e.target.checked)
                          }
                        />
                        Disable auto-adjust
                      </label>
                    </div>

                    {/* Parts + Additional Fee */}
                    <div className="border rounded p-3 bg-gray-50 space-y-2">
                      <h3 className="text-xs font-semibold">Parts & Fees</h3>

                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[10px] mb-1">
                            Tech Parts
                          </label>
                          <input
                            className="border rounded px-1 py-1 w-full text-xs bg-white"
                            value={techParts}
                            onChange={(e) => setTechParts(e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] mb-1">
                            Lead Parts
                          </label>
                          <input
                            className="border rounded px-1 py-1 w-full text-xs bg-white"
                            value={leadParts}
                            onChange={(e) => setLeadParts(e.target.value)}
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] mb-1">
                            Company Parts
                          </label>
                          <input
                            className="border rounded px-1 py-1 w-full text-xs bg-white"
                            value={companyParts}
                            onChange={(e) => setCompanyParts(e.target.value)}
                          />
                        </div>
                      </div>

                      {/* Additional Fee */}
                      <div className="grid grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[10px] mb-1">
                            Add Fee ($)
                          </label>
                          <input
                            className="border rounded px-1 py-1 w-full text-xs bg-white"
                            value={leadAdditionalFee}
                            onChange={(e) =>
                              setLeadAdditionalFee(e.target.value)
                            }
                          />
                        </div>
                        <div></div>

                        <div className="col-span-2 space-y-1 mt-4">
                          <label className="inline-flex items-center gap-2 text-[11px]">
                            <input
                              type="checkbox"
                              checked={techPaysAdditionalFee}
                              onChange={(e) =>
                                setTechPaysAdditionalFee(e.target.checked)
                              }
                            />
                            Tech pays additional fee
                          </label>

                          <label className="inline-flex items-center gap-2 text-[11px]">
                            <input
                              type="checkbox"
                              checked={excludeTechFromParts}
                              onChange={(e) =>
                                setExcludeTechFromParts(e.target.checked)
                              }
                            />
                            Exclude tech from paying lead/company parts
                          </label>

                          <label className="inline-flex items-center gap-2 text-[11px]">
                            <input
                              type="checkbox"
                              checked={includePartsInProfit}
                              onChange={(e) =>
                                setIncludePartsInProfit(e.target.checked)
                              }
                            />
                            Include parts in profit (visual)
                          </label>
                        </div>
                      </div>

                      {/* Invoice # */}
                      <label className="text-xs">Invoice #</label>
                      <input
                        className="border rounded px-2 py-1 w-full text-sm"
                        value={invoiceNumberState}
                        onChange={(e) =>
                          setInvoiceNumberState(e.target.value)
                        }
                        placeholder="Example: 2025-00123"
                      />
                    </div>

                    {/* SUMMARY */}
                    <div className="border rounded p-3 bg-gray-50 text-xs space-y-2">
                      <h3 className="font-semibold mb-1">Totals & Balances</h3>

                      {result ? (
                        <div className="space-y-2">
                          <div className="grid grid-cols-2 gap-2">
                            <div>
                              <div>Total $</div>
                              <div className="font-mono">
                                ${result.totalAmount.toFixed(2)}
                              </div>
                            </div>
                            <div>
                              <div>Parts $</div>
                              <div className="font-mono">
                                ${result.totalParts.toFixed(2)}
                              </div>
                            </div>
                            <div>
                              <div>CC Fee $</div>
                              <div className="font-mono">
                                ${result.totalCcFee.toFixed(2)}
                              </div>
                            </div>
                            <div>
                              <div>Adj Total</div>
                              <div className="font-mono">
                                ${result.adjustedTotal.toFixed(2)}
                              </div>
                            </div>
                          </div>

                          <div className="border-t my-1"></div>

                          <div className="grid grid-cols-3 gap-2">
                            <div>
                              <div>Tech Profit</div>
                              <div className="font-mono">
                                ${result.techProfit.toFixed(2)}
                              </div>
                              <div
                                className={`font-mono ${
                                  result.techBalance < 0
                                    ? "text-red-600"
                                    : "text-green-600"
                                }`}
                              >
                                Bal ${result.techBalance.toFixed(2)}
                              </div>
                            </div>

                            <div>
                              <div>Lead Profit</div>
                              <div className="font-mono">
                                ${result.leadProfit.toFixed(2)}
                              </div>
                              <div
                                className={`font-mono ${
                                  result.leadBalance < 0
                                    ? "text-red-600"
                                    : "text-green-600"
                                }`}
                              >
                                Bal ${result.leadBalance.toFixed(2)}
                              </div>
                            </div>

                            <div>
                              <div>Company Profit</div>
                              <div className="font-mono">
                                ${result.companyProfit.toFixed(2)}
                              </div>
                              <div
                                className={`font-mono ${
                                  result.companyBalance < 0
                                    ? "text-red-600"
                                    : "text-green-600"
                                }`}
                              >
                                Bal ${result.companyBalance.toFixed(2)}
                              </div>
                            </div>
                          </div>

                          <div className="text-[11px] text-gray-500">
                            <span className="font-bold">SumCheck:</span>{" "}
                            <span
                              className={
                                Math.abs(result.sumCheck) < 0.01
                                  ? "text-green-600"
                                  : "text-red-600"
                              }
                            >
                              {result.sumCheck.toFixed(4)}
                            </span>
                          </div>
                        </div>
                      ) : (
                        <p className="text-gray-400 text-[11px]">
                          Enter values → press <b>Close Job</b>.
                        </p>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          const r = calculateSplit();
                          if (!r)
                            return toast.error("Run calculation first");
                          handleCloseJob(r, invoiceNumberState);
                        }}
                        className="mt-2 w-full bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold py-2 rounded"
                      >
                        Close Job (Calculate)
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* LOG TAB */}
      {tab === "log" && (
  <div className="mt-6 space-y-4">
    {job.logs?.length ? (
      job.logs.map((log) => (
        <div key={log.id} className="p-4 border rounded bg-gray-50">

          {/* Header */}
          <div className="flex justify-between text-xs text-gray-500 mb-1">
            <span>{new Date(log.createdAt).toLocaleString()}</span>

            <span className="px-2 py-0.5 rounded bg-gray-200 text-gray-700">
              {log.type === "parsed_sms" ? "🟦 SMS Pasted" : log.type.toUpperCase()}
            </span>
          </div>

          {/* Username */}
          {log.user && (
            <div className="text-xs text-gray-600 mb-1">
              Pasted by: <b>{log.user.name}</b>
            </div>
          )}

          {/* Body */}
          <div className="whitespace-pre-line text-sm bg-white p-2 rounded border">
            {log.text}
          </div>
        </div>
      ))
    ) : (
      <p className="text-sm text-gray-500">No logs yet.</p>
    )}
  </div>
)}

      {/* RECORDINGS TAB */}
      {tab === "recordings" && (
  <div className="space-y-4 mt-4">
    <h2 className="text-lg font-semibold">Call Recordings</h2>

    {!job.callSessions?.length && (
      <p className="text-gray-500 text-sm">
        No call sessions yet — extension is created only when masked calls are used.
      </p>
    )}

    <button
      onClick={async () => {
        const res = await fetch(
          `${base}/jobs/short/${shortId}/recordings`,
          { credentials: "include" }
        );
        const data = await res.json();

        if (!res.ok) return toast.error("Failed to load recordings");
        if (!Array.isArray(data) || !data.length)
          return toast.info("No recordings found");

        setJob((prev) => ({
          ...prev!,
          recordings: data,
        }));

        toast.success("Recordings loaded");
      }}
      className="px-3 py-2 bg-blue-600 text-white rounded text-sm"
    >
      Refresh Recordings
    </button>

    {/* RECORDINGS LIST */}
    {Array.isArray((job as any).recordings) &&
      (job as any).recordings.length > 0 && (
        <div className="space-y-4">
          {(job as any).recordings.map((rec: any) => (
            <div
              key={rec.id}
              className="border rounded p-4 bg-gray-50 dark:bg-gray-900"
            >
              <div className="flex justify-between text-xs text-gray-500 mb-2">
                <span>{new Date(rec.createdAt).toLocaleString()}</span>
                <span className="font-mono">{rec.callSid}</span>
              </div>

              <p className="text-sm">
                <b>From:</b> {rec.from}  
                <br />
                <b>To:</b> {rec.to}
              </p>

              <audio
                controls
                src={rec.url}
                className="mt-2 w-full"
              ></audio>

              <a
                href={rec.url}
                download
                className="text-blue-600 underline text-xs mt-2 inline-block"
              >
                Download MP3
              </a>
            </div>
          ))}
        </div>
      )}
  </div>
)}
    </div>
  );
}

/* Small reusable input component */

function Editable({
  label,
  value,
  onChange,
  textarea = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  textarea?: boolean;
}) {
  return (
    <div>
      <label className="block text-sm font-medium">{label}</label>
      {textarea ? (
        <textarea
          className="mt-1 w-full border rounded p-2 min-h-[80px]"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
      ) : (
        <input
          className="mt-1 w-full border rounded p-2"
          value={value}
          onChange={(e) => onChange(e.target.value)}
        />
      )}
    </div>
  );
}