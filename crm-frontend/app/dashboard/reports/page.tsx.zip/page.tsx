"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import ReportsTable from "./ReportsTable";

export default function ReportsPage() {
  const router = useRouter();

  // ============== STATE ==============
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState<any>(null);

  const [filters, setFilters] = useState({
    from: "",
    to: "",
    technicianId: "",
    jobTypeId: "",
  });

  // Load technicians + jobTypes for dropdowns
  const [technicians, setTechnicians] = useState<any[]>([]);
  const [jobTypes, setJobTypes] = useState<any[]>([]);

  const base = process.env.NEXT_PUBLIC_API_URL;

  // ============== LOAD FILTER OPTIONS ==============
  useEffect(() => {
    async function loadOptions() {
      try {
        const [tRes, jRes] = await Promise.all([
          fetch(`${base}/users?role=technician`, { credentials: "include" }),
          fetch(`${base}/job-types`, { credentials: "include" }),
        ]);
        setTechnicians(await tRes.json());
        setJobTypes(await jRes.json());
      } catch {
        toast.error("Failed to load filter options");
      }
    }
    loadOptions();
  }, []);

  // ============== FETCH REPORT ==============
  async function loadReport() {
    setLoading(true);

    const params = new URLSearchParams();

    if (filters.from) params.append("from", filters.from);
    if (filters.to) params.append("to", filters.to);
    if (filters.technicianId) params.append("technicianId", filters.technicianId);
    if (filters.jobTypeId) params.append("jobTypeId", filters.jobTypeId);

    try {
      const res = await fetch(`${base}/reports?${params.toString()}`, {
        credentials: "include",
      });

      const json = await res.json();
      if (!res.ok) {
        toast.error(json.error || "Report load failed");
      } else {
        setData(json);
      }
    } catch (err) {
      toast.error("Network error");
    }

    setLoading(false);
  }

  // ============== UI ==============
  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold">📊 Job Reports</h1>

      {/* --------------------- FILTERS --------------------- */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 border rounded p-4 bg-gray-50">
        
        {/* FROM */}
        <div>
          <label className="text-sm font-medium">From</label>
          <input
            type="date"
            className="w-full border p-2 rounded"
            value={filters.from}
            onChange={(e) =>
              setFilters({ ...filters, from: e.target.value })
            }
          />
        </div>

        {/* TO */}
        <div>
          <label className="text-sm font-medium">To</label>
          <input
            type="date"
            className="w-full border p-2 rounded"
            value={filters.to}
            onChange={(e) =>
              setFilters({ ...filters, to: e.target.value })
            }
          />
        </div>

        {/* TECH FILTER */}
        <div>
          <label className="text-sm font-medium">Technician</label>
          <select
            className="w-full border p-2 rounded"
            value={filters.technicianId}
            onChange={(e) =>
              setFilters({ ...filters, technicianId: e.target.value })
            }
          >
            <option value="">All</option>
            {technicians.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} ({t.phone})
              </option>
            ))}
          </select>
        </div>

        {/* JOB TYPE FILTER */}
        <div>
          <label className="text-sm font-medium">Job Type</label>
          <select
            className="w-full border p-2 rounded"
            value={filters.jobTypeId}
            onChange={(e) =>
              setFilters({ ...filters, jobTypeId: e.target.value })
            }
          >
            <option value="">All</option>
            {jobTypes.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* BUTTON */}
      <button
        onClick={loadReport}
        disabled={loading}
        className="px-4 py-2 bg-blue-600 text-white rounded shadow"
      >
        {loading ? "Loading..." : "Load Report"}
      </button>

      {/* --------------------- REPORT RESULT --------------------- */}
      {data && (
        <div className="space-y-6">
          {/* ============= KPIs ============ */}
{data?.summary && (
  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
    <KPI title="Total Revenue" value={`$${data.summary.totalRevenue}`} />
    <KPI title="Tech Profit" value={`$${data.summary.totalTechProfit}`} />
    <KPI title="Lead Profit" value={`$${data.summary.totalLeadProfit}`} />
    <KPI title="Company Profit" value={`$${data.summary.totalCompanyProfit}`} />
  </div>
)}

 {/* TABLE — PLACE IT HERE */}
      {data?.rows && <ReportsTable rows={data.jobs} />}

          {/* ============ TABLE ============ */}
          <div className="border rounded overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 text-left">
                <tr>
                  <th className="p-2">Date</th>
                  <th className="p-2">Job</th>
                  <th className="p-2">Tech</th>
                  <th className="p-2">Total</th>
                  <th className="p-2">Tech Profit</th>
                  <th className="p-2">Lead Profit</th>
                  <th className="p-2">Company Profit</th>
                </tr>
              </thead>
              <tbody>
                {data.jobs.map((j: any) => (
                  <tr key={j.id} className="border-t">
                    <td className="p-2">
                      {new Date(j.createdAt).toLocaleDateString()}
                    </td>
                    <td className="p-2">{j.title}</td>
                    <td className="p-2">
                      {j.technician?.name || "-"}
                    </td>
                    <td className="p-2">${j.closing?.totalAmount || 0}</td>
                    <td className="p-2">${j.closing?.techProfit || 0}</td>
                    <td className="p-2">${j.closing?.leadProfit || 0}</td>
                    <td className="p-2">${j.closing?.companyProfitDisplay || 0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------- KPI Component ------------------- */
function KPI({ title, value }: { title: string; value: string }) {
  return (
    <div className="border rounded p-4 bg-white shadow text-center">
      <div className="text-sm text-gray-500">{title}</div>
      <div className="text-xl font-bold">{value}</div>
    </div>
  );
}